Mensagem recebida de mundopremiado.com.br

<p>
<b>Nome:</b> {{ $nome }}
</p>

<p>
<b>E-mail:</b> {{ $email }}
</p>


<b>Mensagem:</b> {{  nl2br($mensagem) }}
