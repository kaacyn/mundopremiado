Mensagem recebida de mundopremiado.com.br

<p>
<b>Nome:</b> {{ $nome }}
</p>

<p>
<b>E-mail:</b> {{ $email }}
</p>

<p>
<b>Hotsite:</b> {{ $hotsite }}
</p>

<b>Observação:</b> {{  nl2br($observacao) }}
