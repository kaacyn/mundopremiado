@extends('frontend.layout')

@section('title', "Sobre - " )
@section('description',  "Portal de promoções diversas (promoções, sorteios,premiações, brindes,produtos/serviços/ações promocionais)." )

@section('content')

  <div class="container">

    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <h1 class="titulo">Sobre o Mundo Premiado</h1>


      </div>
    </div>
    <div class="row">
    
      <div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
          <p>Portal de promoções diversas (promoções, sorteios,premiações, brindes,produtos/serviços/ações promocionais).</p>

          <p>Tendo como objetivo oferecer um portal confiável, buscando maior facilidade de acesso e participação em promoções diversas, gerando assim maiores chances de receber premiações.</p>
      </div>
      <div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
          
      </div>
    </div>

  </div>
@stop