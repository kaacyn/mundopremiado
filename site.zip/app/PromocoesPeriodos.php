<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PromocoesPeriodos extends Model
{
    //
}
