<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProdutosLojistas extends Model
{
    //
}
